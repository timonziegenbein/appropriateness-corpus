
$(document).ready(function () {
    $('#annotated-form').submit(function (e) {
        $(".error").remove();
    });

});
